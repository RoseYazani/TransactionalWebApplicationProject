import sqlite3
import bcrypt
from flask import Flask, session, redirect, render_template, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required



app = Flask(__name__)
app.secret_key = 'allo'
login_manager = LoginManager()
login_manager.init_app(app)
# without setting the login_view, attempting to access @login_required endpoints will result in an error
# this way, it will redirect to the login page
login_manager.login_view = 'login'
app.config['USE_SESSION_FOR_NEXT'] = True


class User(UserMixin):
    def __init__(self, username, email, phone, password=None, role='general'):
        self.id = username
        self.email = email
        self.phone = phone
        self.password = password
        self.role = role


# this is used by flask_login to get a user object for the current user
@login_manager.user_loader
def load_user(user_id):
    user = find_user(user_id)
    # user could be None
    if user:
        # if not None, hide the password by setting it to None
        user.password = None
    return user


def find_user(username):
    con = sqlite3.connect("data/users.sqlite")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT username, email, phone, password FROM users WHERE username = '{}';".format(username))
    user = cur.fetchone()
    con.close()
    if user:
        user = User(*user)
    return user


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = find_user(form.username.data)
        # user could be None
        # passwords are kept in hashed form, using the bcrypt algorithm
        if user and bcrypt.checkpw(form.password.data.encode(), user.password.encode()):
            login_user(user)
            flash('Logged in successfully.')

            # check if the next page is set in the session by the @login_required decorator
            # if not set, it will default to '/'
            next_page = session.get('next', '/')
            # reset the next page to default '/'
            session['next'] = '/'
            return redirect(next_page)
        else:
            flash('Incorrect username/password!')
    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    # flash(str(session))
    return redirect('/')


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        # check first if user already exists
        user = find_user(form.username.data)
        if not user:
            salt = bcrypt.gensalt()
            password = bcrypt.hashpw(form.password.data.encode(), salt)
            con = sqlite3.connect("data/users.sqlite")
            cur = con.cursor()
            cur.execute("INSERT INTO users(username, email, phone, password)VALUES('{}', '{}', '{}', '{}');".format(
                form.username.data, form.email.data, form.phone.data, password.decode()))
            con.commit()
            con.close()
            flash('Registered successfully.')
            return redirect('/login')
        else:
            flash('This username already exists, choose another one')
    return render_template('register.html', form=form)


@app.route('/')
def index():
    return render_template('index.html',
                           title='The Sacred Heart School of Montreal',)


@app.route('/organization')
def organization():
    headings = ('Name', 'Position', 'Email')
    data = [('Mr. Shawn O’Donnell', 'Head of School', 'sodonnell@sacredheart.qc.ca'),
                     ('Ms. Anika Maloni (Alumna)', 'Assistant Head of School & Director of Academics',
                      'amaloni@sacredheart.qc.ca'),
                     ('Ms. Iveth Bosmediano', 'Director of Finance', 'ibosmediano@sacredheart.qc.ca'),
                     ('Ms. Stephanie Broadhurst', 'Director of Enrolment Management', 'sbroadhurst@sacredheart.qc.ca'),
                     ('Mrs. Lili Le Fèvre (Past Parent)', 'Director of Advancement & Communications',
                      'llefevre@sacredheart.qc.ca'),
                     ('Ms. Maria Cusma-Dovico (Alumna)', 'Ethics, Religion & Social Sciences',
                      'mcusma@sacredheart.qc.ca'),
                     ('Mr. Josh Friedmann', 'Math', 'jfriedmann@sacredheart.qc.ca'),
                     ('Mr. Angelo Gallo', 'Social Sciences', 'agallo@sacredheart.qc.ca'),
                     ('Mme Catherine Gauthier', 'French', 'cgauthier@sacredheart.qc.ca'),
                     ('Ms. Sarah Jones', 'English', 'sjones@sacredheart.qc.ca'),
                     ('Ms. Jennifer Newton (Alumna)', 'Physical Education', 'jnewton@sacredheart.qc.ca'),
                     ('Mr. David Reda', ' Science & Grade 12 Math', 'dreda@sacredheart.qc.ca'),
                     ('Ms. Aran Waldbrook', ' Fine Arts (website', 'awaldbrook@sacredheart.qc.ca'),
                     ('Ms. Lara Artinian (Alumna)', 'Science (leave of absence)', 'lartinian@sacredheart.qc.ca'),
                     ('Mr. Julian Beauvais', 'Psychology & English', 'jbeauvais@sacredheart.qc.ca'),
                     ('Ms. Maureen Brown (Alumna, Past Parent)', 'Drama', 'mbrown@sacredheart.qc.ca'),
                     ('Mr. Pooyan Haghighat', 'Science & Math, Grade 12 Science', 'phaghighat@sacredheart.qc.ca'),
                     ('Mr. Peter Judson', ' Science', 'pjudson@sacredheart.qc.ca'),
                     ('Ms. Kennedy Lane', 'English, Religion & Social Sciences', 'klane@sacredheart.qc.ca'),
                     ('Ms. Alexandra Lantosh (Alumna)', 'Social Sciences', 'alantosh@sacredheart.qc.ca'),
                     ('Mme Marie-Elaine Laquerre', 'French', 'melaquerre@sacredheart.qc.ca'),
                     ('Ms. Krystal Lapierre', 'Science & Math', 'krystallapierre@sacredheart.qc.ca'),
                     ('Ms. Kristina Lisak', 'French', 'klisak@sacredheart.qc.ca'),
                     ('Ms. Megan Littman', 'Director of Athletics & Student Life Coordinator',
                      'mlittman@sacredheart.qc.ca'),
                     ('Mr. James McRae', 'Math & Science', 'jmcrae@sacredheart.qc.ca'),
                     ('Mr. Rommy Nashi', ' French', 'rommynashi@sacredheart.qc.ca'),
                     ('Mme Myriam Phaneuf', 'F.S.L.', 'mphaneuf@sacredheart.qc.ca'),
                     ('Ms. Lauren Quintal', 'Math & Science', 'lquintal@sacredheart.qc.ca'),
                     ('Ms. Miranda Ramchatesingh', ' Art', 'mramchatesingh@sacredheart.qc.ca'),
                     ('Ms. Ashley Thorup', 'English', 'ashleythorup@sacredheart.qc.ca'), ]
    return render_template('organization.html',
                           title = 'The Sacred Heart School of Montreal',
                           headings = headings,
                           data = data)


@app.route('/careers')
@login_required
def careers():
    con = sqlite3.connect("data/users.sqlite")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM careers ")
    careerslist = cur.fetchall()

    con.close()

    return render_template('careers.html', careerslist=careerslist)


@app.route('/news')
@login_required
def news():
    con = sqlite3.connect("data/users.sqlite")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM news ")
    newslist = cur.fetchall()

    con.close()

    return render_template('news.html', newslist=newslist)


if __name__ == '__main__':
    app.run()
